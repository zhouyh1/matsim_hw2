#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  3 15:41:19 2023

@author: vongvanicht
"""

import pandas as pd
import numpy as np
import datetime

#macbook
directory = "/Users/vongvanicht/Downloads/matsim-serengeti-park-hodenhagen-master/scenarios/serengeti-park-v1.0/output/output-serengeti-park-v1.0-run1/"
filename = "serengeti-park-v1.0-run1.output_trips.csv"
shuttle_whole = pd.read_csv(directory + filename, sep = ';')
directory = "/Users/vongvanicht/Downloads/matsim-serengeti-park-hodenhagen-master/scenarios/serengeti-park-v1.0/output/output-serengeti-park-v1.0-base/"
filename = "serengeti-park-v1.0-run1.output_trips.csv"
base_whole = pd.read_csv(directory + filename, sep = ';')
sample_data = shuttle_whole.head(10)
#print(sample_data.iloc[1])

data = shuttle_whole

# Split the travel time into hours, minutes, and seconds
split_time = data['trav_time'].str.split(':', expand=True).astype(int)
# Calculate the total travel time in minutes, ignoring the seconds
total_travel_time = split_time.iloc[:, 0] * 60 + split_time.iloc[:, 1]
# Calculate the total travel distance
total_travel_distance = data['traveled_distance'].sum()
print("Shuttle case:")
print("Total travel time:", total_travel_time.sum())
print("Total travel distance:", total_travel_distance)

import matplotlib.pyplot as plt
# Define the bin edges
bin_edges = np.arange(0, 141, 20)
bin_edges = np.append(bin_edges, np.inf)
# Plot histogram of travel time
plt.hist(total_travel_time, bins=bin_edges, edgecolor='black', color='red')
# Set labels and title
plt.xlabel('Travel Time (minutes)')
plt.ylabel('Frequency')
plt.title('Histogram of Travel Time: Motorway')
plt.ylim(0, 90000)
# Display the histogram
plt.show()

mode_counts = shuttle_whole['main_mode'].value_counts()
print(mode_counts)
plt.figure(figsize=(8, 8))
plt.pie(mode_counts, labels=mode_counts.index, autopct='%1.1f%%')
# Add a title
plt.title('Modal Split of Trips: Motorway')
# Display the chart
plt.show()


data = base_whole
#data = sample_data
# Split the travel time into hours, minutes, and seconds
split_time = data['trav_time'].str.split(':', expand=True).astype(int)
# Calculate the total travel time in minutes, ignoring the seconds
total_travel_time = split_time.iloc[:, 0] * 60 + split_time.iloc[:, 1]
# Calculate the total travel distance
total_travel_distance = data['traveled_distance'].sum()
print("Base case:")
print("Total travel time (minutes):", total_travel_time.sum())
print("Total travel distance:", total_travel_distance)

import matplotlib.pyplot as plt
# Define the bin edges
bin_edges = np.arange(0, 141, 20)
bin_edges = np.append(bin_edges, np.inf)
# Plot histogram of travel time
plt.hist(total_travel_time, bins=bin_edges, edgecolor='black', color='blue')
# Set labels and title
plt.xlabel('Travel Time (minutes)')
plt.ylabel('Frequency')
plt.title('Histogram of Travel Time: Base')
plt.ylim(0, 90000)
# Display the histogram
plt.show()

mode_counts = base_whole['main_mode'].value_counts()
print(mode_counts)
plt.figure(figsize=(8, 8))
plt.pie(mode_counts, labels=mode_counts.index, autopct='%1.1f%%')
# Add a title
plt.title('Modal Split of Trips: Base')
# Display the chart
plt.show()



#########
#     affectted people
#########


# Read the text file
with open('somename2.txt', 'r') as file:
    person_ids = file.readlines()
# Remove newline characters and whitespace
person_ids = [person_id.strip().replace('Person ID: ', '') for person_id in person_ids]
person_ids_set = set(person_ids)
# Initialize the total travel distance
total_distance = 0
total_travel_time = datetime.timedelta()

# Iterate over each person ID
for person_id in person_ids:
    # Assuming you have a DataFrame called 'trips' containing the trip information
    person_trips = base_whole[base_whole['person'] == person_id]
    person_trips['traveled_distance'] = person_trips['traveled_distance'].astype(float)
    
    # Convert travel time strings to timedelta objects
    person_trips['trav_time'] = pd.to_timedelta(person_trips['trav_time'])
    
    total_distance += person_trips['traveled_distance'].sum()
    total_travel_time += person_trips['trav_time'].sum()

# Print the total travel distance and total travel time
print("Base Case:")
print("Total travel distance:", total_distance)
print("Total travel time:", total_travel_time)


city_counts = {}

with open('home_somename2.txt', 'r') as file:
    for line in file:
        if line.startswith("Person ID"):
            continue
        city = line.strip()
        if city not in city_counts:
            city_counts[city] = 1
        else:
            city_counts[city] += 1

sorted_cities = sorted(city_counts.items(), key=lambda x: x[1], reverse=True)

for city, count in sorted_cities:
    print(f"{city}: {count}")









