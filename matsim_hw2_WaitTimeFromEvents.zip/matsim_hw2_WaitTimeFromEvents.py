#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 16:23:46 2023

@author: vongvanicht
"""

from xml.etree import ElementTree as ET

tree = ET.parse('/Users/vongvanicht/Downloads/matsim-serengeti-park-hodenhagen-master/scenarios/serengeti-park-v1.0/output/output-serengeti-park-v1.0-run1/serengeti-park-v1.0-run1.output_events.xml')
root = tree.getroot()

# Function to calculate total and average wait times
def calculate_wait_times(root):
    # Parse the XML data

    # Create a dictionary to store the enter and exit times of visitors
    visitor_start_times = {}
    wait_times = []

    # Iterate through the events
    for event in root.findall('event'):
        time = float(event.get('time'))
        person = event.get('person')
        event_type = event.get('type')

        if event_type == 'waitingForPt':
            # Store the time when a person starts waiting for pt
            visitor_start_times[person] = time
        elif event_type == 'PersonEntersVehicle' and person in visitor_start_times:
            # Calculate the wait time and remove the entry from the dictionary
            start_time = visitor_start_times[person]
            wait_time = time - start_time
            wait_times.append(wait_time)
            del visitor_start_times[person]

    # Calculate the total and average wait times
    total_wait_time = sum(wait_times)
    average_wait_time = total_wait_time / len(wait_times) if len(wait_times) > 0 else 0

    return total_wait_time, average_wait_time



# Calculate wait times for the sample data
total_wait_time, average_wait_time = calculate_wait_times(root)

print(f"Total wait time for pt: {total_wait_time} seconds")
print(f"Average wait time for pt: {average_wait_time} seconds")



# =============================================================================
# # Parse the events file
# tree = ET.parse('/Users/vongvanicht/Downloads/matsim-serengeti-park-hodenhagen-master/scenarios/serengeti-park-v1.0/output/output-serengeti-park-v1.0-run1/serengeti-park-v1.0-run1.output_eventsSample.xml')
# root = tree.getroot()
# 
# # Create a dictionary to store the enter and exit times of visitors
# visitor_start_times = {}
# count = 0
# 
# # Iterate through the events
# for event in root.findall('event'):
#     #count +=1
#     #print(count)
#     print(event)
#     time = float(event.get('time'))
#     person = event.get('person')
#     event_type = event.get('type')
# 
#     if event_type == 'waitingForPt':
#         # Store the time when a person starts waiting for pt
#         visitor_start_times[person] = time
#     elif event_type == 'PersonEntersVehicle' and person in visitor_start_times:
#         # Calculate the wait time and remove the entry from the dictionary
#         start_time = visitor_start_times[person]
#         wait_time = time - start_time
#         del visitor_start_times[person]
#         print(f"Person: {person}, Wait Time: {wait_time} seconds")
# =============================================================================

